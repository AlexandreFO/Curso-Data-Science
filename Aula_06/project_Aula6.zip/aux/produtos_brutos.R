
clamp <- function(x,min,max) case_when(x<min~min,
                                       x>max~max,
                                       T~x)
df_produtos_valores %>%
  select(id_produto,Valor,ValorNum) %>%
  mutate(margem=clamp(rnorm(nrow(df_produtos_valores),.2,.1),.05,.35),
         ValorNumBruto=(ValorNum*(1-margem))%>%sprintf("%.2f",.),
         ValorBruto=str_replace(str_c("R$ ",ValorNumBruto),fixed("."),",")) %>% 
  select(id_produto,ValorBruto) %>% write_csv("produto_custos.csv")
