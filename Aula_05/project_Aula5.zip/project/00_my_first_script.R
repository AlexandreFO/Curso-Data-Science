1 # ctrl-enter
1+1 # isto é um comentário
a <- 10
b <- a + 10

# selectionar a linha e ctrl-enter executa.

# Este é um comentário

1 # selectionar + ctrl-enter (maçã+enter)

1+1
# comentário
10*5

30/4

#Carregar bibliotecas

library(tidyverse)

# isto é um comentário.

# exponenciação:

2^4
16^0.5

# numeros inteiros:

5L

30L/4L

# divisao inteira:

30 %/% 4

# resto:

30 %% 4

# vetores:

1:10

c(5,6,7)

5:10

# vetorização:

1:10 + 1


c(1,2,3,4,5,6,7,8,9,10)

1:10 * 2

# tamanhos diferentes, gera erro:
1:10 + 2:10

# mesmo tamanho, não gera erro:
1:10 + 101:110

vec <- 100:200

length(vec)

# strings

c("rio", "sao paulo", "belo horizonte")


"maçã"
str_length("maçã")

str_length(c("banana","maçã"))

"um string longo"

str_sub("um string longo", start = 4, end=9)

str_c("rio de", " janeiro",", ","brasil")

# variáveis

pi <- 3.1415
pi^2

meus_numeros <- c(5,13,7)

length(meus_numeros)

sum(meus_numeros)


minhas_frutas <- c("banana","maçã")
length(minhas_frutas)
str_length(minhas_frutas)

# data_frame

df <- tibble(estado=c("RJ", "5a55", "MG"),
             capital=c("rio", "são paulo", "belo horizonte"),
             populacao_estadual=c(30,2*30,(3/2)*30))


glimpse(df)
ncol(df)
nrow(df)
dim(df)


df %>% mutate(z=x+y)

df2 <- df %>% mutate(z=x+y)

